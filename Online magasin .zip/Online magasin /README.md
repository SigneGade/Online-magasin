# flexnavdropdown
responsiv navigation med dropdown

Dropdown er med hovereffekt i tablet og større, men dropdown er foldet ud i mobilstørrelsen.
